const form = document.querySelector("form")

// salvar informações locais
form.addEventListener("submit", ev => {
    ev.preventDefault()
    localStorage.setItem("casado", form.casado.checked)
    localStorage.setItem("idade", form.idade.value)
    localStorage.setItem("cidade", form.cidade.value)
    localStorage.setItem("naturalidade", form.naturalidade.value)
    localStorage.setItem("cordoOlhos", form.cordosOlhos.value)
    localStorage.setItem("estiloMusical", form.estiloMusical.value)
    alert("Salvou!")
})

// ler informações locais
const casado = localStorage.getItem("casado")
const idade = localStorage.getItem("idade")
const cidade = localStorage.getItem("cidade")
const naturalidade = localStorage.getItem("naturalidade")
const cordosOlhos = localStorage.getItem("cor dos olhos")
const estiloMusical = localStorage.getItem("estiloMusical")

form.casado.checked = (casado === "true") || "true"
form.idade.value = idade ||  27
form.cidade.value = cidade || "     País de Gales"
form.naturalidade.value = naturalidade || "     País de Gales"
form.cordosOlhos.value = cordosOlhos || "    Azul"
form.estiloMusical.value = estiloMusical ||"    Classic"